$( document ).ready(function() {
    // Shift nav in mobile when clicking the menu.
    $(document).on('click', "[data-toggle='wy-nav-top']", function() {
      $("[data-toggle='wy-nav-shift']").toggleClass("shift");
      $("[data-toggle='rst-versions']").toggleClass("shift");
    });
    // Close menu when you click a link.
    $(document).on('click', ".wy-menu-vertical .current ul li a", function() {
      $("[data-toggle='wy-nav-shift']").removeClass("shift");
      $("[data-toggle='rst-versions']").toggleClass("shift");
    });
    $(document).on('click', "[data-toggle='rst-current-version']", function() {
      $("[data-toggle='rst-versions']").toggleClass("shift-up");
    });  
    // Make tables responsive
    $("table.docutils:not(.field-list)").wrap("<div class='wy-table-responsive'></div>");

    var topPx = $(".usa-banner").css("height");
    $(".wy-body-for-nav").css("padding-top",topPx);
    $(".wy-nav-side").css({'min-height': `calc(100% - ${topPx}px)`});
    //banner toggle
    $(document).on('click', ".usa-banner-button", function() {
        // $(".usa-accordion-content").slideToggle(250);
        $(".usa-accordion-content").toggleClass("hidden");
        $(".usa-banner-header").toggleClass("usa-banner-header-expanded");
        "true" === $(".usa-banner-button").attr("aria-expanded") ? $(".usa-banner-button").attr("aria-expanded", "false") : $(".usa-banner-button").attr("aria-expanded", "true");
        var topPx = $(".usa-banner").css("height");
        $(".wy-body-for-nav").css("padding-top",topPx);
        $(".wy-nav-side").css({'min-height': `calc(100% - ${topPx}px)`});
        $(".stickynav").css("top",topPx);
        
    });  
    $(window).resize(function(){
        var topPx = $(".usa-banner").css("height");
        $(".wy-body-for-nav").css("padding-top",topPx);
        $(".wy-nav-side").css({'min-height': `calc(100% - ${topPx}px)`});
    });
});

window.SphinxRtdTheme = (function (jquery) {
    var stickyNav = (function () {
        var navBar,
            win,
            stickyNavCssClass = 'stickynav',
            winScroll = false,
            enable = function () {
                navBar.addClass(stickyNavCssClass);
                win.on('scroll', function() { // set flag on scroll event
                    winScroll = true;
                });
                // use setInterval to only handle a subset of scroll events so we don't kill scroll performance
                setInterval(function() {
                    if (winScroll) {
                        winScroll = false;
                        navBar.scrollTop(win.scrollTop());
                    }
                }, 100);
            },
            init = function () {
                navBar = jquery('nav.wy-nav-side:first');
                win    = jquery(window);
            };
        jquery(init);
        return {
            enable : enable
        };
    }());
    return {
        StickyNav : stickyNav
    };
}($));
